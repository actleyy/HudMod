package com.hudmod;

import net.fabricmc.loader.api.FabricLoader;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public enum Elem {
    KEYSTROKES("Keystrokes HUD", 0.02f, 0.35f),
    ARMOR("Armor HUD", 0.90f, 0.35f),
    POTION("Potion HUD", 0.82f, 0.02f),
    PING("Ping Display", 0.02f, 0.10f),
    FPS_COORDS("FPS & Coordinates", 0.02f, 0.02f),
    CPS("CPS Counter", 0.02f, 0.22f);

    public final String label;
    public final float defX, defY;
    public boolean enabled = true;
    public float x, y, scale = 1.0f; // x,y = fraction of screen (0..1)

    Elem(String label, float x, float y) {
        this.label = label;
        this.defX = x;
        this.defY = y;
        this.x = x;
        this.y = y;
    }

    public void reset() {
        x = defX;
        y = defY;
        scale = 1.0f;
        enabled = true;
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("hudmod.properties");
    }

    public static void load() {
        try {
            Path f = file();
            if (!Files.exists(f)) return;
            Properties p = new Properties();
            try (InputStream in = Files.newInputStream(f)) {
                p.load(in);
            }
            for (Elem e : values()) {
                e.enabled = Boolean.parseBoolean(p.getProperty(e.name() + ".on", "true"));
                e.x = Float.parseFloat(p.getProperty(e.name() + ".x", String.valueOf(e.defX)));
                e.y = Float.parseFloat(p.getProperty(e.name() + ".y", String.valueOf(e.defY)));
                e.scale = Float.parseFloat(p.getProperty(e.name() + ".s", "1.0"));
            }
        } catch (Exception ignored) {
        }
    }

    public static void save() {
        try {
            Properties p = new Properties();
            for (Elem e : values()) {
                p.setProperty(e.name() + ".on", String.valueOf(e.enabled));
                p.setProperty(e.name() + ".x", String.valueOf(e.x));
                p.setProperty(e.name() + ".y", String.valueOf(e.y));
                p.setProperty(e.name() + ".s", String.valueOf(e.scale));
            }
            try (OutputStream out = Files.newOutputStream(file())) {
                p.store(out, "HUD Mod");
            }
        } catch (Exception ignored) {
        }
    }
}

package com.hudmod;

import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

public class HudMenuScreen extends HudBaseScreen {

    public HudMenuScreen() {
        super(Component.literal("HUD Mod - Right Shift"));
    }

    private static Component label(Elem e) {
        return Component.literal(e.label + ": " + (e.enabled ? "ON" : "OFF"));
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int y = this.height / 2 - 75;
        for (Elem e : Elem.values()) {
            addRenderableWidget(Button.builder(label(e), b -> {
                e.enabled = !e.enabled;
                b.setMessage(label(e));
                Elem.save();
            }).bounds(cx - 90, y, 150, 20).build());

            addRenderableWidget(Button.builder(Component.literal("\u270E"),
                    b -> this.minecraft.setScreen(new HudEditScreen(e, this)))
                    .bounds(cx + 65, y, 25, 20).build());
            y += 24;
        }
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(cx - 50, y + 6, 100, 20).build());
    }
}

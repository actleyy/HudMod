package com.hudmod;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;

public class HudMod implements ClientModInitializer {

    public static final KeyMapping.Category CATEGORY =
            KeyMapping.Category.register(Identifier.fromNamespaceAndPath("hudmod", "main"));

    public static KeyMapping MENU_KEY;

    @Override
    public void onInitializeClient() {
        Elem.load();

        MENU_KEY = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.hudmod.menu", InputConstants.Type.KEYSYM, 344 /* Right Shift */, CATEGORY));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            Cps.update();
            while (MENU_KEY.consumeClick()) {
                if (mc.player != null && mc.screen == null) {
                    mc.setScreen(new HudMenuScreen());
                }
            }
        });

        HudRenderCallback.EVENT.register((g, delta) -> {
            Minecraft mc = Minecraft.getInstance();
            Cps.update();
            if (mc.player == null || mc.options.hideGui) return;
            if (mc.screen instanceof HudBaseScreen) return;
            HudRenderer.drawAll(g);
        });
    }
}

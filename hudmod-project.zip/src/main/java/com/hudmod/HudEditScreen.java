package com.hudmod;

import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.function.Consumer;
import java.util.function.Function;

public class HudEditScreen extends HudBaseScreen {
    private final Elem elem;
    private final Screen parent;

    public HudEditScreen(Elem elem, Screen parent) {
        super(Component.literal("Edit: " + elem.label));
        this.elem = elem;
        this.parent = parent;
    }

    private static class Sl extends AbstractSliderButton {
        private final Consumer<Double> apply;
        private final Function<Double, String> text;

        Sl(int x, int y, int w, double v, Consumer<Double> apply, Function<Double, String> text) {
            super(x, y, w, 20, Component.empty(), v);
            this.apply = apply;
            this.text = text;
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            if (text != null) setMessage(Component.literal(text.apply(this.value)));
        }

        @Override
        protected void applyValue() {
            apply.accept(this.value);
        }
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int y = this.height - 110;
        addRenderableWidget(new Sl(cx - 100, y, 200, elem.x,
                v -> elem.x = v.floatValue(),
                v -> "Position X: " + Math.round(v * 100) + "%"));
        addRenderableWidget(new Sl(cx - 100, y + 24, 200, elem.y,
                v -> elem.y = v.floatValue(),
                v -> "Position Y: " + Math.round(v * 100) + "%"));
        addRenderableWidget(new Sl(cx - 100, y + 48, 200, (elem.scale - 0.5) / 1.5,
                v -> elem.scale = (float) (0.5 + v * 1.5),
                v -> "Size: " + Math.round((0.5 + v * 1.5) * 100) + "%"));
        addRenderableWidget(Button.builder(Component.literal("Reset"), b -> {
            elem.reset();
            this.rebuildWidgets();
        }).bounds(cx - 100, y + 72, 98, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> {
            Elem.save();
            this.minecraft.setScreen(parent);
        }).bounds(cx + 2, y + 72, 98, 20).build());
    }
}

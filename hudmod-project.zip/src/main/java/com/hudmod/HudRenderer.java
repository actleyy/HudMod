package com.hudmod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;

public class HudRenderer {

    private static final int ON_BG = 0xB0FFFFFF;
    private static final int OFF_BG = 0x80000000;

    public static void drawAll(GuiGraphics g) {
        for (Elem e : Elem.values()) {
            if (e.enabled) draw(g, e);
        }
    }

    public static void draw(GuiGraphics g, Elem e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        int px = Math.round(e.x * g.guiWidth());
        int py = Math.round(e.y * g.guiHeight());
        g.pose().pushMatrix();
        g.pose().translate((float) px, (float) py);
        g.pose().scale(e.scale, e.scale);
        switch (e) {
            case KEYSTROKES -> keystrokes(g, mc);
            case ARMOR -> armor(g, mc);
            case POTION -> potion(g, mc);
            case PING -> ping(g, mc);
            case FPS_COORDS -> fpsCoords(g, mc);
            case CPS -> cps(g, mc);
        }
        g.pose().popMatrix();
    }

    private static void key(GuiGraphics g, Minecraft mc, String t, int x, int y, int w, int h, boolean down) {
        g.fill(x, y, x + w, y + h, down ? ON_BG : OFF_BG);
        int tw = mc.font.width(t);
        g.drawString(mc.font, t, x + (w - tw) / 2, y + (h - 8) / 2 + 1, down ? 0xFF000000 : 0xFFFFFFFF, false);
    }

    private static void keystrokes(GuiGraphics g, Minecraft mc) {
        var o = mc.options;
        key(g, mc, "W", 20, 0, 18, 18, o.keyUp.isDown());
        key(g, mc, "A", 0, 20, 18, 18, o.keyLeft.isDown());
        key(g, mc, "S", 20, 20, 18, 18, o.keyDown.isDown());
        key(g, mc, "D", 40, 20, 18, 18, o.keyRight.isDown());
        key(g, mc, "SPACE", 0, 40, 58, 12, o.keyJump.isDown());
        key(g, mc, "LMB " + Cps.left(), 0, 54, 28, 14, o.keyAttack.isDown());
        key(g, mc, "RMB " + Cps.right(), 30, 54, 28, 14, o.keyUse.isDown());
    }

    private static void armor(GuiGraphics g, Minecraft mc) {
        LocalPlayer p = mc.player;
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        int y = 0;
        for (EquipmentSlot s : slots) {
            ItemStack st = p.getItemBySlot(s);
            if (!st.isEmpty()) {
                g.renderItem(st, 0, y);
                if (st.isDamageableItem()) {
                    int left = st.getMaxDamage() - st.getDamageValue();
                    int pct = Math.round(100f * left / st.getMaxDamage());
                    int col = pct > 50 ? 0xFF55FF55 : pct > 20 ? 0xFFFFFF55 : 0xFFFF5555;
                    g.drawString(mc.font, left + "/" + st.getMaxDamage(), 20, y + 4, col, true);
                } else {
                    g.drawString(mc.font, "-", 20, y + 4, 0xFFFFFFFF, true);
                }
            }
            y += 18;
        }
    }

    private static void potion(GuiGraphics g, Minecraft mc) {
        int y = 0;
        for (MobEffectInstance inst : mc.player.getActiveEffects()) {
            String name = inst.getEffect().value().getDisplayName().getString();
            int amp = inst.getAmplifier() + 1;
            String time;
            if (inst.isInfiniteDuration()) {
                time = "inf";
            } else {
                int sec = inst.getDuration() / 20;
                time = (sec / 60) + ":" + String.format("%02d", sec % 60);
            }
            g.drawString(mc.font, name + " " + amp + "  " + time, 0, y, 0xFFFFFFFF, true);
            y += 11;
        }
        if (y == 0) g.drawString(mc.font, "No effects", 0, 0, 0xFFAAAAAA, true);
    }

    private static void ping(GuiGraphics g, Minecraft mc) {
        int ms = 0;
        ClientPacketListener c = mc.getConnection();
        if (c != null) {
            var info = c.getPlayerInfo(mc.player.getUUID());
            if (info != null) ms = info.getLatency();
        }
        int col = ms < 80 ? 0xFF55FF55 : ms < 160 ? 0xFFFFFF55 : 0xFFFF5555;
        g.drawString(mc.font, "Ping: " + ms + " ms", 0, 0, col, true);
    }

    private static void fpsCoords(GuiGraphics g, Minecraft mc) {
        g.drawString(mc.font, "FPS: " + mc.getFps(), 0, 0, 0xFFFFFFFF, true);
        String xyz = String.format("XYZ: %.1f / %.1f / %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ());
        g.drawString(mc.font, xyz, 0, 11, 0xFFFFFFFF, true);
    }

    private static void cps(GuiGraphics g, Minecraft mc) {
        g.drawString(mc.font, "CPS: " + Cps.left() + " | " + Cps.right(), 0, 0, 0xFFFFFFFF, true);
    }
}
